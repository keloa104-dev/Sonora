package com.example.ui.components

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AudioTrack
import com.example.model.FolderNode

enum class SheetSortMode {
    DEFAULT,
    TITLE_ASC,
    ARTIST_ASC,
    DURATION
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistBottomSheet(
    queueTracks: List<AudioTrack>,
    currentTrack: AudioTrack?,
    folderTrees: List<FolderNode> = emptyList(),
    onTrackSelect: (AudioTrack) -> Unit,
    onPlayTrackList: (List<AudioTrack>, Int) -> Unit,
    onMoveItem: (fromIndex: Int, toIndex: Int) -> Unit,
    onRemoveItem: (index: Int) -> Unit,
    onClearQueue: () -> Unit = {},
    onDeleteTracks: (List<AudioTrack>, onComplete: () -> Unit) -> Unit = { _, _ -> },
    onMoveTracks: (List<AudioTrack>) -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedTrackIds by remember(selectedTabIndex) { mutableStateOf(setOf<Long>()) }

    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(SheetSortMode.DEFAULT) }

    val playlistFolderStack = remember { mutableStateListOf<FolderNode>() }

    LaunchedEffect(selectedTabIndex) {
        playlistFolderStack.clear()
        searchQuery = ""
        isSearchActive = false
        sortMode = SheetSortMode.DEFAULT
    }

    val selectedFolderNode = if (selectedTabIndex > 0 && selectedTabIndex - 1 < folderTrees.size) {
        folderTrees[selectedTabIndex - 1]
    } else null

    val activeFolderNode = if (playlistFolderStack.isNotEmpty()) {
        playlistFolderStack.last()
    } else {
        selectedFolderNode
    }

    val currentTabTracks = remember(selectedTabIndex, queueTracks, activeFolderNode) {
        if (selectedTabIndex == 0) {
            queueTracks
        } else {
            activeFolderNode?.tracks ?: emptyList()
        }
    }

    val totalDiscoveredCount = remember(selectedTabIndex, queueTracks, activeFolderNode) {
        if (selectedTabIndex == 0) {
            queueTracks.size
        } else {
            activeFolderNode?.totalTrackCount() ?: activeFolderNode?.tracks?.size ?: 0
        }
    }

    // Filter tracks by search query
    val filteredTracks = remember(currentTabTracks, searchQuery) {
        if (searchQuery.isBlank()) {
            currentTabTracks
        } else {
            val query = searchQuery.trim().lowercase()
            currentTabTracks.filter { track ->
                track.title.lowercase().contains(query) ||
                track.artist.lowercase().contains(query) ||
                track.album.lowercase().contains(query)
            }
        }
    }

    // Sort tracks based on active sort mode
    val sortedAndFilteredTracks = remember(filteredTracks, sortMode) {
        when (sortMode) {
            SheetSortMode.DEFAULT -> filteredTracks
            SheetSortMode.TITLE_ASC -> filteredTracks.sortedBy { it.title.lowercase() }
            SheetSortMode.ARTIST_ASC -> filteredTracks.sortedBy { it.artist.lowercase() }
            SheetSortMode.DURATION -> filteredTracks.sortedByDescending { it.durationMs }
        }
    }

    // Filter subfolders by search query
    val filteredSubfolders = remember(activeFolderNode, searchQuery) {
        val subs = activeFolderNode?.subfolders ?: emptyList()
        if (searchQuery.isBlank()) {
            subs
        } else {
            val query = searchQuery.trim().lowercase()
            subs.filter { sub ->
                sub.name.lowercase().contains(query) ||
                sub.getAllTracksRecursively().any {
                    it.title.lowercase().contains(query) || it.artist.lowercase().contains(query)
                }
            }
        }
    }

    // NestedScrollConnection that intercepts downward overscroll to strictly prevent
    // ModalBottomSheet from interpreting downward scroll inside the list as pull-to-dismiss!
    val preventDismissNestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                return if (available.y > 0f) Offset(0f, available.y) else Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                return if (available.y > 0f) Velocity(0f, available.y) else Velocity.Zero
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            when {
                selectedTrackIds.isNotEmpty() -> {
                    selectedTrackIds = emptySet()
                }
                isSearchActive && searchQuery.isNotEmpty() -> {
                    searchQuery = ""
                }
                isSearchActive -> {
                    isSearchActive = false
                }
                playlistFolderStack.isNotEmpty() -> {
                    playlistFolderStack.removeAt(playlistFolderStack.lastIndex)
                }
                selectedTabIndex > 0 -> {
                    selectedTabIndex = 0
                }
                else -> {
                    onDismiss()
                }
            }
        },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp),
        scrimColor = Color.Black.copy(alpha = 0.65f),
        modifier = Modifier.testTag("playlist_bottom_sheet")
    ) {
        // High-Priority Hierarchical Back Navigation Shield inside ModalBottomSheet Window Context:
        // Ensures system back button and gestures pop subfolders from playlistFolderStack first!
        BackHandler {
            when {
                selectedTrackIds.isNotEmpty() -> {
                    selectedTrackIds = emptySet()
                }
                isSearchActive && searchQuery.isNotEmpty() -> {
                    searchQuery = ""
                }
                isSearchActive -> {
                    isSearchActive = false
                }
                playlistFolderStack.isNotEmpty() -> {
                    playlistFolderStack.removeAt(playlistFolderStack.lastIndex)
                }
                selectedTabIndex > 0 -> {
                    selectedTabIndex = 0
                }
                else -> {
                    onDismiss()
                }
            }
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.90f)
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            // Header: Multi-selection mode OR Clean 3-Row Wireframe Header
            if (selectedTrackIds.isNotEmpty()) {
                // Header when items are selected
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${selectedTrackIds.size} selected",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Select All Button
                        IconButton(
                            onClick = {
                                val isAllSelected = selectedTrackIds.size == sortedAndFilteredTracks.size
                                selectedTrackIds = if (isAllSelected) emptySet() else sortedAndFilteredTracks.map { it.id }.toSet()
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("sheet_select_all_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CheckBox,
                                contentDescription = "Select All",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Delete Button (Queue Tab only)
                        if (selectedTabIndex == 0) {
                            IconButton(
                                onClick = {
                                    val selectedList = currentTabTracks.filter { selectedTrackIds.contains(it.id) }
                                    if (selectedList.isNotEmpty()) {
                                        onDeleteTracks(selectedList) {
                                            selectedTrackIds = emptySet()
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("sheet_delete_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        // Move Button
                        IconButton(
                            onClick = {
                                val selectedList = currentTabTracks.filter { selectedTrackIds.contains(it.id) }
                                onMoveTracks(selectedList)
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("sheet_move_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = "Move",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Play Selected Button
                        IconButton(
                            onClick = {
                                val selectedList = currentTabTracks.filter { selectedTrackIds.contains(it.id) }
                                if (selectedList.isNotEmpty()) {
                                    onPlayTrackList(selectedList, 0)
                                    selectedTrackIds = emptySet()
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("sheet_play_selected_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play Selected",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Cancel selection
                        IconButton(
                            onClick = { selectedTrackIds = emptySet() },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel Selection",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else {
                // Strict 3-Row Wireframe Header Layout
                // ROW 1: Navigation + Main Title
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (playlistFolderStack.isNotEmpty()) {
                        IconButton(
                            onClick = { playlistFolderStack.removeAt(playlistFolderStack.lastIndex) },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("playlist_folder_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Text(
                        text = if (selectedTabIndex == 0) "Play Queue" else (activeFolderNode?.name ?: "Folder"),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }

                // ROW 2: Context / Song Count + Action Button (Play All)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (selectedTabIndex == 0) {
                            if (queueTracks.isEmpty()) {
                                "Queue is empty"
                            } else {
                                val currentIndex = if (currentTrack != null) queueTracks.indexOfFirst { it.id == currentTrack.id } else -1
                                val remaining = if (currentIndex >= 0) queueTracks.size - currentIndex - 1 else queueTracks.size
                                if (remaining > 0) "${queueTracks.size} songs • $remaining remaining" else "${queueTracks.size} songs"
                            }
                        } else {
                            "$totalDiscoveredCount songs"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    if (selectedTabIndex > 0 && sortedAndFilteredTracks.isNotEmpty()) {
                        Button(
                            onClick = {
                                onPlayTrackList(sortedAndFilteredTracks, 0)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(18.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("queue_play_all_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play All",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Play All",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }

                // ROW 3: Action Toolbar (Flat Search on Left, Flat Sort/Clean on Right — NO CIRCULAR BACKGROUNDS)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Search Icon (Flat, no circular background)
                    IconButton(
                        onClick = {
                            isSearchActive = !isSearchActive
                            if (!isSearchActive) searchQuery = ""
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("sheet_search_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Music",
                            tint = if (isSearchActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Right side Actions (Flat Clear Queue or Flat Sort Menu — NO CIRCULAR BACKGROUNDS)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (selectedTabIndex == 0 && queueTracks.isNotEmpty()) {
                            IconButton(
                                onClick = onClearQueue,
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("sheet_clear_queue_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ClearAll,
                                    contentDescription = "Clear Queue",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        // Sort / Filter Flat Icon Button
                        Box {
                            var showSortMenu by remember { mutableStateOf(false) }
                            IconButton(
                                onClick = { showSortMenu = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("sheet_sort_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Sort,
                                    contentDescription = "Sort Tracks",
                                    tint = if (sortMode != SheetSortMode.DEFAULT) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "Default Order",
                                            fontWeight = if (sortMode == SheetSortMode.DEFAULT) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        sortMode = SheetSortMode.DEFAULT
                                        showSortMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "Title (A to Z)",
                                            fontWeight = if (sortMode == SheetSortMode.TITLE_ASC) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        sortMode = SheetSortMode.TITLE_ASC
                                        showSortMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "Artist (A to Z)",
                                            fontWeight = if (sortMode == SheetSortMode.ARTIST_ASC) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        sortMode = SheetSortMode.ARTIST_ASC
                                        showSortMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "Duration",
                                            fontWeight = if (sortMode == SheetSortMode.DURATION) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        sortMode = SheetSortMode.DURATION
                                        showSortMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Search Bar (Animated Expandable)
                AnimatedVisibility(
                    visible = isSearchActive,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("sheet_search_text_field"),
                        placeholder = {
                            Text(
                                text = "Search tracks & folders...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear Search",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Navigation Tabs (Scrollable Tab Row)
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex.coerceIn(0, folderTrees.size),
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    val safeIndex = selectedTabIndex.coerceIn(0, (tabPositions.size - 1).coerceAtLeast(0))
                    if (safeIndex in tabPositions.indices) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[safeIndex]),
                            color = MaterialTheme.colorScheme.primary,
                            height = 3.dp
                        )
                    }
                },
                divider = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("queue_folder_tabs_row")
            ) {
                // Queue Tab
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "Queue (${queueTracks.size})",
                            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.QueueMusic,
                            contentDescription = "Queue",
                            tint = if (selectedTabIndex == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier.testTag("queue_tab_0")
                )

                // Folder Tabs
                folderTrees.forEachIndexed { fIndex, folderNode ->
                    val tabIndex = fIndex + 1
                    val isSelected = selectedTabIndex == tabIndex
                    val trackCount = folderNode.getAllTracksRecursively().size
                    Tab(
                        selected = isSelected,
                        onClick = { selectedTabIndex = tabIndex },
                        text = {
                            Text(
                                text = "${folderNode.name} ($trackCount)",
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = folderNode.name,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        modifier = Modifier.testTag("queue_folder_tab_$tabIndex")
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val hasSubfolders = selectedTabIndex > 0 && activeFolderNode != null && filteredSubfolders.isNotEmpty()

            if (sortedAndFilteredTracks.isEmpty() && !hasSubfolders) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = if (searchQuery.isNotBlank()) Icons.Default.Search else Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) {
                                "No tracks matching \"$searchQuery\""
                            } else if (selectedTabIndex == 0) {
                                "Queue is empty."
                            } else {
                                "Folder has no audio tracks."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                val listState = rememberLazyListState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .nestedScroll(preventDismissNestedScrollConnection)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 16.dp)
                    ) {
                        if (hasSubfolders) {
                            item {
                                Text(
                                    text = "SUBDIRECTORIES (${filteredSubfolders.size})",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.2.sp
                                    ),
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                                )
                            }
                            items(filteredSubfolders, key = { "bottom_sub_${it.id}" }) { subfolder ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { playlistFolderStack.add(subfolder) }
                                        .testTag("bottom_subfolder_${subfolder.name}"),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Folder,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = subfolder.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "${subfolder.tracks.size} direct tracks • ${subfolder.totalTrackCount()} total",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.ChevronRight,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                            if (sortedAndFilteredTracks.isNotEmpty()) {
                                item {
                                    Text(
                                        text = "FILES IN PATH (${sortedAndFilteredTracks.size})",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.2.sp
                                        ),
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                                    )
                                }
                            }
                        }

                        itemsIndexed(
                            sortedAndFilteredTracks,
                            key = { index, track -> track.id * 10007L + index }
                        ) { index, track ->
                            val isCurrent = currentTrack?.id == track.id
                            val isSelected = selectedTrackIds.contains(track.id)

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        if (selectedTrackIds.isNotEmpty()) {
                                            selectedTrackIds = if (isSelected) selectedTrackIds - track.id else selectedTrackIds + track.id
                                        } else {
                                            if (selectedTabIndex == 0) {
                                                onTrackSelect(track)
                                            } else {
                                                onPlayTrackList(sortedAndFilteredTracks, index)
                                            }
                                        }
                                    }
                                    .testTag("queue_item_${track.id}"),
                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                                else if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(12.dp),
                                border = if (isCurrent) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        // Selection Checkbox
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = { checked ->
                                                selectedTrackIds = if (checked) selectedTrackIds + track.id else selectedTrackIds - track.id
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = MaterialTheme.colorScheme.primary,
                                                uncheckedColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            ),
                                            modifier = Modifier
                                                .size(36.dp)
                                                .testTag("queue_checkbox_${track.id}")
                                        )

                                        Spacer(modifier = Modifier.width(4.dp))

                                        Icon(
                                            imageVector = if (isCurrent) Icons.Default.GraphicEq else Icons.Default.MusicNote,
                                            contentDescription = if (isCurrent) "Now Playing" else null,
                                            tint = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp)
                                        )

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = track.title,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f, fill = false)
                                                )
                                                if (isCurrent) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.primary
                                                    ) {
                                                        Text(
                                                            text = "NOW PLAYING",
                                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onPrimary,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "${track.artist} • ${track.album}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    if (selectedTabIndex == 0 && selectedTrackIds.isEmpty()) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                                            modifier = Modifier.padding(start = 4.dp)
                                        ) {
                                            // Move Up
                                            if (index > 0) {
                                                IconButton(
                                                    onClick = { onMoveItem(index, index - 1) },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowUpward,
                                                        contentDescription = "Move Up",
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }

                                            // Move Down
                                            if (index < queueTracks.size - 1) {
                                                IconButton(
                                                    onClick = { onMoveItem(index, index + 1) },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ArrowDownward,
                                                        contentDescription = "Move Down",
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }

                                            // Delete from Queue
                                            IconButton(
                                                onClick = { onRemoveItem(index) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteOutline,
                                                    contentDescription = "Delete",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    VerticalScrollbar(
                        state = listState,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
            }
        }
    }
}
